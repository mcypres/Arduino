plot (speed)
plot (d)
yyaxis right
plot(y)
hold
yyaxis left
plot(speed)